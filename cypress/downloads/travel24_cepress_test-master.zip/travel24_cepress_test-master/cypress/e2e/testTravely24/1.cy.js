const PRODUCT_TYPE = 'hotelonly';
const DATE_FROM = '2022-12-07';
const DATE_TO = '2022-12-12';

const verifyPrice = (numberString) => {
  const index = numberString.indexOf(' ');
  return Number(numberString.slice(0, index).replace(',', '.'));
};

describe('Test #1 --- 27.09.2022', () => {
  it('Visit site travely24', () => {
    cy.visit(
      `https://www.travely24.com/de/tours/777?hid=33104&productType=${PRODUCT_TYPE}&period=5&adults=2&children&fa=NYC&sDate=${DATE_FROM}&eDate=${DATE_TO}&roomType=ROO.NM&boardType=RO&PT=hotelonly`
    );
  });

  it('Test checked', () => {
    cy.get(
      '[disabled="true"] > .item-tour-form > :nth-child(1) > input#withFlight.custom-checkbox-map',
      {
        timeout: 10000,
      }
    )
      .should(PRODUCT_TYPE === 'hotelonly' ? 'not.be.checked' : 'be.checked') // test PRODUCT_TYPE
      .then(() => console.log(`Expected checkbox "Flug" not to be checked`));

    cy.get('div[style=""] > .item-tour-form > :nth-child(1) > input', {
      timeout: 10000,
    })
      .should(PRODUCT_TYPE === 'hotelonly' ? 'be.checked' : 'not.be.checked') // test PRODUCT_TYPE
      .then(() =>
        console.log(
          `Expected checkbox "Crowne Plaza Newark Airport" to be checked`
        )
      );
  });

  it('Test from and to date', () => {
    cy.get('.item-tour-form-column > .block-fly-text', {
      timeout: 10000,
    }).then((state) => {
      const innerText = state.get(0).innerText;
      const indexN = innerText.indexOf('\n');
      const siteFromDay = innerText.slice(0, 2);
      const siteFromYear = innerText.slice(Number(indexN) - 4, Number(indexN));
      const siteFromDate = new Date(`12.${siteFromDay}.${siteFromYear}`);

      const siteToDay = innerText.slice(Number(indexN) + 1, Number(indexN) + 3);
      const siteToYear = innerText.slice(
        innerText.length - 5,
        innerText.length
      );
      const siteToDate = new Date(`12.${siteToDay}.${siteToYear}`);

      const daySite = (siteToDate - siteFromDate) / 1000 / 60 / 60 / 24;
      const dayStat =
        (new Date(DATE_TO) - new Date(DATE_FROM)) / 1000 / 60 / 60 / 24;

      const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      };
      const newFromDate = new Date(DATE_FROM)
        .toLocaleDateString('de-DE', options)
        .replace('.', '');
      const newToDate = new Date(DATE_TO)
        .toLocaleDateString('de-DE', options)
        .replace('.', '');
      expect(state.get(0).innerText).to.eq(`0${newFromDate}\n${newToDate}`);
      expect(daySite).to.eq(dayStat);
    });
  });
  it('Test name hotel', () => {
    cy.get('.block-single-content-top-title', {
      timeout: 10000,
    }).then((mainNameHotel) => {
      cy.get(
        'div[style=""] > .item-tour-form > :nth-child(2) > .block-fly-text-top',
        {
          timeout: 10000,
        }
      ).then((state) => {
        expect(mainNameHotel.get(0).innerText).to.eq(
          state.get(0).innerText.replace(' ', '')
        );
      });
    });
  });
  it('Test price - any', () => {
    cy.get('.totalPriceBlock > :nth-child(2)', {
      timeout: 10000,
    }).then((priceRight) => {
      const numberPriceRight = verifyPrice(priceRight.get(0).innerText);
      cy.get('.option-price', {
        timeout: 10000,
      }).then((priceLeft) => {
        const numberPriceLeft = verifyPrice(priceLeft.get(0).innerText);
        expect(numberPriceLeft).to.be.closeTo(numberPriceRight, 100);
      });
    });
  });

  it('Click show all room offers and select room: test price and name - strictly', () => {
    cy.get('.roomName', {
      timeout: 10000,
    }).then((oldName) => {
      cy.get('[style="padding: 0px; display: block;"] > .btn-blue', {
        timeout: 10000,
      }).click({ force: true });
      cy.get(':nth-child(3) > .collapseCategory', {
        timeout: 10000,
      }).click({ force: true });
      cy.get(
        ':nth-child(4) > .block-options-room-wrapper > .room-wrapper > [data-index="0"] > .block-contents-wrapper > .price-add-block-option > :nth-child(2)',
        {
          timeout: 10000,
        }
      ).click({ force: true });
      cy.get(
        ':nth-child(4) > .block-options-room-wrapper > .room-wrapper > [data-index="0"] > .block-contents-wrapper > .price-add-block-option > .option-price'
      ).then((selectPrice) => {
        cy.get('.totalPriceBlock > :nth-child(2)', { timeout: 10000 }).then(
          (statePrice) => {
            expect(
              cy
                .get('.totalPriceBlock > :nth-child(2) > img', {
                  timeout: 10000,
                })
                .should('have.css', 'display', 'none')
                .then(() => {
                  expect(verifyPrice(selectPrice.get(0).innerText)).to.eq(
                    verifyPrice(statePrice.get(0).innerText)
                  );
                })
            );
          }
        );
      });

      cy.get('.popup-top-close > .fas', {
        timeout: 10000,
      }).click({ force: true });
      cy.get('.roomName', {
        timeout: 10000,
      }).then((newName) => {
        expect(oldName.get(0).innerText).not.to.eq(newName.get(0).innerText);
      });
    });
  });
});
