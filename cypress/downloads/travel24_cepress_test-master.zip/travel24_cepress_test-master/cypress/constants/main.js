import { addDate } from '../customFunction/date';

export const FD_URL_FROM = 'CGN';
export const FA_URL_TO = 'VRN';
export const FROM_DEFAULT = 'FRA';
export const TO_DEFAULT = 'VRN';

export const NEW_FROM_DEFAULT = 'ABC';

export const CHILDREN_DEFAULT = '3,11';
export const ADULTS_DEFAULT = '3';

export const FROM_DATE_DEFAULT = addDate(5);
export const TO_DATE_DEFAULT = addDate(9);

export const PRODUCT_TYPE = 'flight';
