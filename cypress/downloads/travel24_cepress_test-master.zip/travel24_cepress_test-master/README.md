# Не забудь поставить звезду
## npm i - установить проект
## npx cypress open - запуск Cypress
