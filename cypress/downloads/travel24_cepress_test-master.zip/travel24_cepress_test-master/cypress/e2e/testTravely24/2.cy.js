const PRODUCT_TYPE = 'flight';
const DATE_FROM = '2022-10-09';
const DATE_TO = '2022-10-10';

const FROM_COUNTRY_API = 'FRA';
const TO_COUNTRY_API = 'VCE';

const API_URL = `https://www.travely24.com/api/?r=aer&search=1&from=${FROM_COUNTRY_API}&to=${TO_COUNTRY_API}&dateFrom=2022-10-09&dateTo=2022-10-10&direct=0&cabinClassBusiness=0&adults=2&children=`;

const verifyPrice = (numberString) => {
  const index = numberString.indexOf(' ');
  const numberSite = Number(numberString.slice(0, index));
  return numberSite;
};

describe('Test #2 --- 01.10.2022', () => {
  Cypress.on('fail', (error, runnable) => {
    //debugger; //on debugger
    console.log(`Error test name: ${runnable.title}`);
    console.log(error);
    console.log(runnable);
    throw error;
  });

  it('Visit site travely24', () => {
    cy.visit(
      `https://www.travely24.com/de/tours/1393?period=1&adults=2&children&hid=62836&fa=VCE&sDate=${DATE_FROM}&eDate=${DATE_TO}&productType=${PRODUCT_TYPE}&flight=EW815|EW814|`
    );
  });

  context('Test checked', () => {
    it('Test checked fly', () => {
      cy.get('[disabled="false"] > .item-tour-form > :nth-child(1) > input', {
        timeout: 10000,
      })
        .should(PRODUCT_TYPE === 'flight' ? 'be.checked' : 'not.be.checked') // test PRODUCT_TYPE
        .then(() => console.log(`Expected checkbox "Fly" to be checked`));
    });
    it('Test not checked hotel', () => {
      cy.get(
        '[style="opacity: 0.5;"] > .item-tour-form > :nth-child(1) > input',
        {
          timeout: 10000,
        }
      )
        .should(PRODUCT_TYPE !== 'flight' ? 'be.checked' : 'not.be.checked') // test PRODUCT_TYPE
        .then(() => console.log(`Expected checkbox "Hotel" not to be checked`));
    });
  });

  context('Test text from and to fly', () => {
    it('Test text from fly', () => {
      cy.get(
        '[disabled="false"] > .item-tour-form > :nth-child(2) > .block-fly-text',
        {
          timeout: 100000,
        }
      ).then((text) => {
        const arrayText = text.get(0).innerText.split(/ |\n/);
        const verifyText =
          arrayText.findIndex((text) => text === FROM_COUNTRY_API) >= 0;
        console.log(
          `Verify text "${FROM_COUNTRY_API}" to "${text.get(0).innerText
          }" = ${verifyText}`
        );
        expect(verifyText).to.be.true;
      });
    });
    it('Test text to fly', () => {
      cy.get(
        '[disabled="false"] > .item-tour-form > :nth-child(2) > .block-fly-text',
        {
          timeout: 100000,
        }
      ).then((text) => {
        const arrayText = text.get(0).innerText.split(/ |\n/);
        const verifyText =
          arrayText.findIndex((text) => text === TO_COUNTRY_API) >= 0;
        console.log(
          `Verify text "${TO_COUNTRY_API}" to "${text.get(0).innerText
          }" = ${verifyText}`
        );
        expect(verifyText).to.be.true;
      });
    });
  });

  context('Test API', () => {
    const newArray = Array.from(Array(15).keys());
    let pricesServer = [];
    it('Test min price and get all prices server', () => {
      cy.request(API_URL).as('flightApi');
      cy.get('@flightApi').then((response) => {
        const {
          body: { availableFareList },
        } = response;
        const minAvailableFareList = availableFareList.reduce((prev, curr) => {
          return prev.passengerTypeFareList[0].priceList <
            curr.passengerTypeFareList[0].priceList
            ? prev
            : curr;
        });
        const priceMinServerArray =
          minAvailableFareList.passengerTypeFareList[0].priceList;
        const sortAvailableFareList = availableFareList.sort((prev, curr) => {
          return prev.passengerTypeFareList[0].priceList <
            curr.passengerTypeFareList[0].priceList
            ? prev
            : curr;
        });

        cy.get('.flight-price', {
          timeout: 100000,
        }).then((text) => {
          const innerText = text.get(0).innerText;
          const index = innerText.indexOf(' ');
          const numberSite = Number(innerText.slice(0, index));
          expect(numberSite).to.be.within(0, priceMinServerArray);
        });
        console.log(sortAvailableFareList);

        pricesServer = sortAvailableFareList.map(
          (item) => item.passengerTypeFareList[0].priceList
        );
      });
    });

    it('Click - show main prices in site', () => {
      cy.get('.block-contents-wrapper > .btn-blue', {
        timeout: 100000,
      }).click({
        force: true,
      });
    });
    it('Click - show 15 prices in site', () => {
      cy.get('.show-more-btn', {
        timeout: 100000,
      }).click({
        force: true,
      });
    });

    newArray.forEach((_item, i) => {
      it(`Test - price site ${i + 1} and min price server ${i + 1}`, () => {
        cy.get(
          `#showedOtherFlights${i} > [style="border: 0px; margin: 0px; width: 100%; --c81fc0a4:9999;"] > :nth-child(1) > :nth-child(1) > .drop-tour-form-fly-ticket > .btn-alternativeFlights-wrapper > .flight-price`,
          { timeout: 100000 }
        ).then((text) => {
          const priceSite = verifyPrice(text.get(0).innerText);

          console.log(
            `Min price site ${i + 1}: ${priceSite} and min price server ${i + 1
            }: ${pricesServer[i]}. Less than or equal to: ${priceSite <= pricesServer[i]
            }`
          );
          expect(priceSite).to.be.within(0, pricesServer[i]);
        });
      });
    });
  });
});
